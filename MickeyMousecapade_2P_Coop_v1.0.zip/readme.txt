================================================================================
  Mickey Mousecapade (NES) - Two-Player Co-op
  Version 1.0                                        Author: SideofClouds
================================================================================

WHAT IT IS

  Mickey Mousecapade is built around two characters but only ever had room for
  one player: Minnie follows Mickey around under CPU control, and controller 2
  does nothing. This hack hands her to a second player.

  Pick TWO PLAYER on the title screen and Minnie answers to controller 2 -- her
  own walking, jumping, swimming, doors, item pickups, and her own star shots.
  Both players are live at once. ONE PLAYER mode is left exactly as it was.


PATCHING

  Apply to an unmodified USA ROM *with* the 16-byte iNES header:

    No-Intro : Mickey Mousecapade (USA).nes
    Size     : 65,552 bytes (65,536 + 16-byte iNES header)
    CRC32    : 1D961110
    MD5      : D634A9B11B464BC2A6C452BAF5A57F3E
    SHA-1    : C37AA6ACFCD64EB51E93E77881BABC8C06779BEE

  Use the .bps with Floating IPS (Flips), beat, or Rom Patcher JS. The BPS
  verifies the ROM's checksum and will refuse the wrong file rather than
  silently corrupting it -- prefer it over the .ips if your patcher supports it.

  The .ips is provided for old patchers only. It carries no checksum: applied
  to a headerless ROM it WILL produce a broken game with no warning.

  Patched result: CRC32 3739A3FC, SHA-1 853FA01A507727058CC1CA5D7CD8D07880D16CBE

  Mapper 3 (CNROM), no expansion hardware. Runs on real hardware and on
  accuracy-focused emulators.


CONTROLS

  Title screen : Up/Down selects ONE PLAYER / TWO PLAYER, Start begins.
  Controller 1 : Mickey.
  Controller 2 : Minnie (TWO PLAYER only).

  In TWO PLAYER, each character shoots with their own B button once the star
  upgrades are collected. In ONE PLAYER, Minnie fires alongside Mickey when
  both star upgrades are collected, exactly as in the original.


WHAT CHANGED

  * Simultaneous two-player co-op; Minnie is fully player-controlled.
  * Title-screen mode select with a star cursor and menu sound effects.
  * ONE PLAYER mode preserves the original behaviour. Every change is gated on
    the selected mode, so the 1P game keeps the original Minnie AI, follow
    logic, and owl kidnapping.
  * The level-select cheat is retired (its Start-button path is reused).
  * Exactly one background tile in CHR bank 0 differs from the original (the
    star used for the menu cursor). No other graphics are touched.


KNOWN ISSUES

  * In ONE PLAYER with only one star upgrade, Minnie can still fire in some
    rooms. The original keeps her silent until both upgrades are collected.


CREDITS

  Hack, disassembly and tooling by SideofClouds.
  Mickey Mousecapade (c) 1987 Hudson Soft / Capcom. This patch distributes no
  copyrighted material -- you must supply your own ROM.
